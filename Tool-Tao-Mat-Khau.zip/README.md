# Random Password Generator

This tool will help to generate Random Password with 8 - 40 lenght. Also support  Dark and Light Theme

**Demo Link**
[https://kamerk22.github.io/random-password-generator/](https://kamerk22.github.io/random-password-generator/)

![Night Theme](https://raw.githubusercontent.com/kamerk22/random-password-generator/master/screenshot/night.png)
![Light Theme](https://raw.githubusercontent.com/kamerk22/random-password-generator/master/screenshot/day.png)

# Features
- Uppercase 
- Lowercase 
- Numeric 
- Symbols

## Credits

- [Kashyap Merai][link-author]
- [All Contributors][link-contributors]
- [Terminal CSS](http://terminalcss.xyz)

## License

MIT. Please see the [license file](license.md) for more information.

[link-author]: https://github.com/kamerk22
[link-contributors]: ../../contributors]
